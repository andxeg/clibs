Telium 2
Telium 3 -> Tetra

==================================USEFUL LINKS=================================
1. Git plugin for sublime text 3. https://github.com/kemayo/sublime-text-git/wiki
2. Hot keys for Windows. https://lifehacker.ru/hotkeys-windows-10/
3. Windows subsystem for Linux. https://www.howtogeek.com/249966/how-to-install-and-use-the-linux-bash-shell-on-windows-10/
https://www.howtogeek.com/344688/how-to-set-your-default-linux-distribution-on-windows-10/
4. https://www.howtogeek.com/265900/everything-you-can-do-with-windows-10s-new-bash-shell/
5. cygwin for windows 10. https://www.scivision.co/cygwin-on-windows-10/
6. git configuration, aliases. https://githowto.com/ru/aliases
7. makefile. https://www.cs.swarthmore.edu/~newhall/unixhelp/howto_makefiles.html
             
8. templates in pure C. https://habr.com/post/154811/
9. vim as IDE. https://coderoncode.com/tools/2017/04/16/vim-the-perfect-ide.html
               https://github.com/amacgregor/dot-files
10. dotfiles in vim and zsh. https://thoughtbot.com/upcase/videos/intro-to-dotfiles
11. pathogen - tool for add vim plugin. https://github.com/tpope/vim-pathogen
12. plugin for vim with file system tree. https://github.com/vim-scripts/The-NERD-tree
13. vim editor commands. https://www.radford.edu/~mhtay/CPSC120/VIM_Editor_Commands.htm
14.	while loop in c macros. https://stackoverflow.com/questions/319328/how-to-write-a-while-loop-with-the-c-preprocessor
http://www.assembleforce.com/2012-08/five-tips-for-your-use-of-macros-in-c.h
15. variadic functions in c. https://modelingwithdata.org/arch/00000022.htm
	https://stackoverflow.com/questions/1472138/c-default-arguments
16. protect tar archive. https://stackoverflow.com/questions/3297056/password-protection-while-creating-tar-file
https://www.tecmint.com/encrypt-decrypt-files-tar-openssl-linux/
17. !!!Обработки ошибок в C. https://habr.com/post/324642/
18. изменение кодировки файла. https://www.shellhacks.com/ru/linux-check-change-file-encoding/
19. compare binary files. https://www.cjmweb.net/vbindiff/
20. compress data with 7-z. https://www.pontikis.net/blog/easily-compress-encrypt-files-using-7z-p7zip-linux
21.	Git tutorial. https://githowto.com/ru/merging_back_to_master
merge if unrelated histories
git checkout master
git merge origin/terminal_dyn_schema --allow-unrelated-histories
22. C references and resources -> http://www.ntu.edu.sg/home/ehchua/programming/howto/References.html#cpp
								  http://www.ntu.edu.sg/home/ehchua/programming/cpp/c0_Introduction.html
23. Timestamp in operating system. https://codereview.stackexchange.com/questions/120628/timestamp-function-with-millisecond-precision 
	clock_gettime for unix, how use it -> http://all-ht.ru/inf/prog/c/func/clock_gettime.html
24.	Cprogramming. https://www.cprogramming.com/c++11/c++11-compile-time-processing-with-constexpr.html
25.	с tutorial. https://www.cprogramming.com/tutorial/c-tutorial.html
26.	c++ tutorial. https://www.cprogramming.com/tutorial/c++-tutorial.html
27.	c++: from beginner to expert. https://www.cprogramming.com/books.html
28.	c/c++ begin. https://www.cprogramming.com/begin.html
29.	
30.	

=====================================PUZZLES===================================
1.	puzzles from interviews. https://www.techinterview.org/
2.	https://www.cprogramming.com/helpfree.html
3.	
4.	
5.	
6.	
7.	
8.	
9.	
10.	

